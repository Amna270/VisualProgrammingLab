﻿using System.Collections.Generic;
public static class Cities
{
    public static List<string> GetCities()
    {
        return new List<string> { "Toronto", "Montreal", "Ottawa", "Calgary", "Halifax" };
    }
}
